function collections = load_collections
filenames = {};
pathnames = {};
[filename, pathname] = uigetfile( ...
       {'*.zip', 'Zip files (*.zip))'; ...
        '*.txt', 'Tab delimited files (*.txt))'; ...
        '*.*', 'All Files (*.*)'}, ...
        'Pick a file (hit cancel when finished)');
while filename ~= 0
    filenames{end+1} = filename;
    pathnames{end+1} = pathname;
    [filename, pathname] = uigetfile( ...
           {'*.zip', 'Zip files (*.zip))'; ...
            '*.txt', 'Tab delimited files (*.txt))'; ...
            '*.*', 'All Files (*.*)'}, ...
            'Pick a file (hit cancel when finished)');
end
if length(filenames) == 0
    return
end

txt_filenames = {};
txt_pathnames = {};
for k = 1:length(filenames)
    if strcmp(filenames{k}(end-2:end),'zip');
        mydir = tempname;
        mkdir(mydir);
        unzip([pathnames{k},filenames{k}],mydir);
        [tfilenames,tpathnames] = list(mydir,[mydir,'\*.txt']);
        txt_filenames = {txt_filenames{:},tfilenames{:}};
        txt_pathnames = {txt_pathnames{:},tpathnames{:}};
    else
        txt_filenames{end+1} = filenames{k};
        txt_pathnames{end+1} = pathnames{k};
    end
end

collections = {};
for i = 1:length(txt_filenames)
    collections{i} = load_collection(txt_filenames{i},txt_pathnames{i})
end
