function res = is_integer(v)
res = int32(v) == v;
