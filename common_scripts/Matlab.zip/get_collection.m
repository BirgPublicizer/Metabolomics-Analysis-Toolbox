function collection = get_collection
username = getappdata(gcf,'username');
password = getappdata(gcf,'password');    
if isempty(username) || isempty(password)
    [username,password] = logindlg;
    setappdata(gcf,'username',username);
    setappdata(gcf,'password',password);
end
prompt={'Collection ID:'};
name='Enter the collection ID from the website';
numlines=1;
defaultanswer={''};
answer=inputdlg(prompt,name,numlines,defaultanswer);
collection_id = str2num(answer{1});

url = sprintf('http://birg.cs.wright.edu/omics_analysis/collections/%d.xml',collection_id);
xml = urlread(url,'get',{'name',username,'password',password});
file = tempname;
fid = fopen(file,'w');
fwrite(fid,xml);
%fprintf(fid,xml);
fclose(fid);
collection_xml = xml2struct(file);
data = collection_xml.Children(2).Children.Data;
file = tempname;
fid = fopen(file,'w');
fwrite(fid,data);
%fprintf(fid,data);
fclose(fid);

collection = load_collection(file,'');