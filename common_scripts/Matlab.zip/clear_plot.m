function clear_plot
try
    clear_all_except_regions

    clear_regions_cursors
catch ME
end